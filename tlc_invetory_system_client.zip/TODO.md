- Property Add Dialog

- Maintenance Tab

  - Repair
    <!-- - Change to Fixed
    - Run Function to API -->
  - Dispose
    <!-- -Check if created_at is more than a year from created at -->
    <!-- - change disabled to false -->

- Property Location
  - must show base on the current stage - if returned show the original location else show lend location

- Dashboard
