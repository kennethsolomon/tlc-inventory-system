export default {
	SET_LOCATIONS(state, locations) {
		state.locations = locations
	}
}

