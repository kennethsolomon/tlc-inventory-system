export default {
  getLocations: state => state.locations
}