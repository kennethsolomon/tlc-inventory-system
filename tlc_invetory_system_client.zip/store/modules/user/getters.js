export default {
  getUser: state => state.user,
  getLogs: state => state.logs,
  getMaintenance: state => state.maintenance
}