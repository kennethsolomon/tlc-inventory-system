export default {
  getEmployees: state => state.employees
}