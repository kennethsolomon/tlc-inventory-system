export default {
	SET_EMPLOYEES(state, employees) {
		state.employees = employees
	}
}