export default {
	SET_ITEM_CATEGORIES(state, item_categories) {
		state.item_categories = item_categories
	}
}