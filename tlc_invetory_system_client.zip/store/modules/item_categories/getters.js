export default {
  getItemCategories: state => state.item_categories
}