export default {
  getItemStatus: state => state.item_status
}