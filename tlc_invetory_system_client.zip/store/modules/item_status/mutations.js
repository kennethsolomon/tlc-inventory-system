export default {
	SET_ITEM_STATUS(state, item_status) {
		state.item_status = item_status
	}
}