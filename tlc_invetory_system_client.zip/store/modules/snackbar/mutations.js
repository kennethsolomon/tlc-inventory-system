export default {
	SET_SNACKBAR(state, snackbar) {
		state.snackbar = snackbar.snackbar
	}
}