export default {
  getSnackbar: state => state.snackbar
}