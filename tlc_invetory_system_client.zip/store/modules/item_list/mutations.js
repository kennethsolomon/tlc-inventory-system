export default {
	SET_ITEM_LIST(state, item_list) {
		state.item_list = item_list
	}
}
