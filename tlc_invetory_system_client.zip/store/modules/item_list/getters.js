export default {
  getItemList: state => state.item_list
}