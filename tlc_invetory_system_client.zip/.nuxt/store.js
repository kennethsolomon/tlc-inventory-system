import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']

let store = {};

(function updateModules () {
  store = normalizeRoot(require('..\\store\\index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  if (typeof store === 'function') {
    return console.warn('Classic mode for store/ is deprecated and will be removed in Nuxt 3.')
  }

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('..\\store\\modules\\user\\index.js'), 'modules/user/index.js')
  resolveStoreModules(require('..\\store\\modules\\snackbar\\index.js'), 'modules/snackbar/index.js')
  resolveStoreModules(require('..\\store\\modules\\locations\\index.js'), 'modules/locations/index.js')
  resolveStoreModules(require('..\\store\\modules\\items\\index.js'), 'modules/items/index.js')
  resolveStoreModules(require('..\\store\\modules\\item_status\\index.js'), 'modules/item_status/index.js')
  resolveStoreModules(require('..\\store\\modules\\item_list\\index.js'), 'modules/item_list/index.js')
  resolveStoreModules(require('..\\store\\modules\\item_categories\\index.js'), 'modules/item_categories/index.js')
  resolveStoreModules(require('..\\store\\modules\\employees\\index.js'), 'modules/employees/index.js')
  resolveStoreModules(require('..\\store\\modules\\employees\\actions.js'), 'modules/employees/actions.js')
  resolveStoreModules(require('..\\store\\modules\\employees\\getters.js'), 'modules/employees/getters.js')
  resolveStoreModules(require('..\\store\\modules\\employees\\mutations.js'), 'modules/employees/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\item_categories\\actions.js'), 'modules/item_categories/actions.js')
  resolveStoreModules(require('..\\store\\modules\\item_categories\\getters.js'), 'modules/item_categories/getters.js')
  resolveStoreModules(require('..\\store\\modules\\item_categories\\mutations.js'), 'modules/item_categories/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\item_list\\actions.js'), 'modules/item_list/actions.js')
  resolveStoreModules(require('..\\store\\modules\\item_list\\getters.js'), 'modules/item_list/getters.js')
  resolveStoreModules(require('..\\store\\modules\\item_list\\mutations.js'), 'modules/item_list/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\item_status\\actions.js'), 'modules/item_status/actions.js')
  resolveStoreModules(require('..\\store\\modules\\item_status\\getters.js'), 'modules/item_status/getters.js')
  resolveStoreModules(require('..\\store\\modules\\item_status\\mutations.js'), 'modules/item_status/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\items\\actions.js'), 'modules/items/actions.js')
  resolveStoreModules(require('..\\store\\modules\\items\\getters.js'), 'modules/items/getters.js')
  resolveStoreModules(require('..\\store\\modules\\items\\mutations.js'), 'modules/items/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\locations\\actions.js'), 'modules/locations/actions.js')
  resolveStoreModules(require('..\\store\\modules\\locations\\getters.js'), 'modules/locations/getters.js')
  resolveStoreModules(require('..\\store\\modules\\locations\\mutations.js'), 'modules/locations/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\snackbar\\actions.js'), 'modules/snackbar/actions.js')
  resolveStoreModules(require('..\\store\\modules\\snackbar\\getters.js'), 'modules/snackbar/getters.js')
  resolveStoreModules(require('..\\store\\modules\\snackbar\\mutations.js'), 'modules/snackbar/mutations.js')
  resolveStoreModules(require('..\\store\\modules\\user\\actions.js'), 'modules/user/actions.js')
  resolveStoreModules(require('..\\store\\modules\\user\\getters.js'), 'modules/user/getters.js')
  resolveStoreModules(require('..\\store\\modules\\user\\mutations.js'), 'modules/user/mutations.js')

  // If the environment supports hot reloading...

  if (process.client && module.hot) {
    // Whenever any Vuex module is updated...
    module.hot.accept([
      '..\\store\\index.js',
      '..\\store\\modules\\user\\index.js',
      '..\\store\\modules\\snackbar\\index.js',
      '..\\store\\modules\\locations\\index.js',
      '..\\store\\modules\\items\\index.js',
      '..\\store\\modules\\item_status\\index.js',
      '..\\store\\modules\\item_list\\index.js',
      '..\\store\\modules\\item_categories\\index.js',
      '..\\store\\modules\\employees\\index.js',
      '..\\store\\modules\\employees\\actions.js',
      '..\\store\\modules\\employees\\getters.js',
      '..\\store\\modules\\employees\\mutations.js',
      '..\\store\\modules\\item_categories\\actions.js',
      '..\\store\\modules\\item_categories\\getters.js',
      '..\\store\\modules\\item_categories\\mutations.js',
      '..\\store\\modules\\item_list\\actions.js',
      '..\\store\\modules\\item_list\\getters.js',
      '..\\store\\modules\\item_list\\mutations.js',
      '..\\store\\modules\\item_status\\actions.js',
      '..\\store\\modules\\item_status\\getters.js',
      '..\\store\\modules\\item_status\\mutations.js',
      '..\\store\\modules\\items\\actions.js',
      '..\\store\\modules\\items\\getters.js',
      '..\\store\\modules\\items\\mutations.js',
      '..\\store\\modules\\locations\\actions.js',
      '..\\store\\modules\\locations\\getters.js',
      '..\\store\\modules\\locations\\mutations.js',
      '..\\store\\modules\\snackbar\\actions.js',
      '..\\store\\modules\\snackbar\\getters.js',
      '..\\store\\modules\\snackbar\\mutations.js',
      '..\\store\\modules\\user\\actions.js',
      '..\\store\\modules\\user\\getters.js',
      '..\\store\\modules\\user\\mutations.js',
    ], () => {
      // Update `root.modules` with the latest definitions.
      updateModules()
      // Trigger a hot update in the store.
      window.$nuxt.$store.hotUpdate(store)
    })
  }
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function normalizeRoot (moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule (moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    console.warn(`'state' should be a method that returns an object in ${filePath}`)

    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function resolveStoreModules (moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const propertyStoreModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(propertyStoreModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeState (moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    console.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function getStoreModule (storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty (storeModule, moduleData, property) {
  if (!moduleData) {
    return
  }

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}
