import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _277bb9fd = () => interopDefault(import('..\\pages\\lend.vue' /* webpackChunkName: "pages/lend" */))
const _4f0bdde2 = () => interopDefault(import('..\\pages\\lend-borrower.vue' /* webpackChunkName: "pages/lend-borrower" */))
const _22d7f57e = () => interopDefault(import('..\\pages\\loan.vue' /* webpackChunkName: "pages/loan" */))
const _70690e4b = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _2d5b7ebd = () => interopDefault(import('..\\pages\\logs.vue' /* webpackChunkName: "pages/logs" */))
const _c8ae2516 = () => interopDefault(import('..\\pages\\maintenance.vue' /* webpackChunkName: "pages/maintenance" */))
const _6175116a = () => interopDefault(import('..\\pages\\maintenance-borrower.vue' /* webpackChunkName: "pages/maintenance-borrower" */))
const _e6941382 = () => interopDefault(import('..\\pages\\property\\index.vue' /* webpackChunkName: "pages/property/index" */))
const _055eb3a0 = () => interopDefault(import('..\\pages\\staff-property.vue' /* webpackChunkName: "pages/staff-property" */))
const _304218ab = () => interopDefault(import('..\\pages\\stocks.vue' /* webpackChunkName: "pages/stocks" */))
const _1463f00e = () => interopDefault(import('..\\pages\\transfer.vue' /* webpackChunkName: "pages/transfer" */))
const _1d86929a = () => interopDefault(import('..\\pages\\trash.vue' /* webpackChunkName: "pages/trash" */))
const _69ba1032 = () => interopDefault(import('..\\pages\\user-management.vue' /* webpackChunkName: "pages/user-management" */))
const _4242727c = () => interopDefault(import('..\\pages\\property\\_propertyid.vue' /* webpackChunkName: "pages/property/_propertyid" */))
const _b27d2998 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/lend",
    component: _277bb9fd,
    name: "lend"
  }, {
    path: "/lend-borrower",
    component: _4f0bdde2,
    name: "lend-borrower"
  }, {
    path: "/loan",
    component: _22d7f57e,
    name: "loan"
  }, {
    path: "/login",
    component: _70690e4b,
    name: "login"
  }, {
    path: "/logs",
    component: _2d5b7ebd,
    name: "logs"
  }, {
    path: "/maintenance",
    component: _c8ae2516,
    name: "maintenance"
  }, {
    path: "/maintenance-borrower",
    component: _6175116a,
    name: "maintenance-borrower"
  }, {
    path: "/property",
    component: _e6941382,
    name: "property"
  }, {
    path: "/staff-property",
    component: _055eb3a0,
    name: "staff-property"
  }, {
    path: "/stocks",
    component: _304218ab,
    name: "stocks"
  }, {
    path: "/transfer",
    component: _1463f00e,
    name: "transfer"
  }, {
    path: "/trash",
    component: _1d86929a,
    name: "trash"
  }, {
    path: "/user-management",
    component: _69ba1032,
    name: "user-management"
  }, {
    path: "/property/:propertyid",
    component: _4242727c,
    name: "property-propertyid"
  }, {
    path: "/",
    component: _b27d2998,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
