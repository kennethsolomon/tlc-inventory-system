# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<NuxtLogo>` | `<nuxt-logo>` (components/NuxtLogo.vue)
- `<Tutorial>` | `<tutorial>` (components/Tutorial.vue)
- `<VuetifyLogo>` | `<vuetify-logo>` (components/VuetifyLogo.vue)
- `<Form>` | `<form>` (components/form/index.vue)
- `<Input>` | `<input>` (components/input/index.vue)
- `<DialogAddIcon>` | `<dialog-add-icon>` (components/dialog/dialog.add.icon.vue)
- `<DialogAdd>` | `<dialog-add>` (components/dialog/dialog.add.vue)
- `<DialogCamera>` | `<dialog-camera>` (components/dialog/dialog.camera.vue)
- `<DialogDelete>` | `<dialog-delete>` (components/dialog/dialog.delete.vue)
- `<DialogUpdate>` | `<dialog-update>` (components/dialog/dialog.update.vue)
- `<PropertyDialogAddProperty>` | `<property-dialog-add-property>` (components/property/dialog.add.property.vue)
- `<PropertyDialogEditProperty>` | `<property-dialog-edit-property>` (components/property/dialog.edit.property.vue)
- `<PropertyDialogQrProperty>` | `<property-dialog-qr-property>` (components/property/dialog.qr.property.vue)
- `<PropertyDialogQrUiProperty>` | `<property-dialog-qr-ui-property>` (components/property/dialog.qr.ui.property.vue)
- `<PropertyDialogStocksProperty>` | `<property-dialog-stocks-property>` (components/property/dialog.stocks.property.vue)
- `<PropertyDialogTemplateProperty>` | `<property-dialog-template-property>` (components/property/dialog.template.property.vue)
- `<Sidebar>` | `<sidebar>` (components/sidebar/index.vue)
- `<Tab>` | `<tab>` (components/tab/index.vue)
