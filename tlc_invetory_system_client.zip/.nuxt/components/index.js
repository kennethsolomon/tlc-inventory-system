export { default as NuxtLogo } from '../..\\components\\NuxtLogo.vue'
export { default as Tutorial } from '../..\\components\\Tutorial.vue'
export { default as VuetifyLogo } from '../..\\components\\VuetifyLogo.vue'
export { default as Form } from '../..\\components\\form\\index.vue'
export { default as Input } from '../..\\components\\input\\index.vue'
export { default as DialogAddIcon } from '../..\\components\\dialog\\dialog.add.icon.vue'
export { default as DialogAdd } from '../..\\components\\dialog\\dialog.add.vue'
export { default as DialogCamera } from '../..\\components\\dialog\\dialog.camera.vue'
export { default as DialogDelete } from '../..\\components\\dialog\\dialog.delete.vue'
export { default as DialogUpdate } from '../..\\components\\dialog\\dialog.update.vue'
export { default as PropertyDialogAddProperty } from '../..\\components\\property\\dialog.add.property.vue'
export { default as PropertyDialogEditProperty } from '../..\\components\\property\\dialog.edit.property.vue'
export { default as PropertyDialogQrProperty } from '../..\\components\\property\\dialog.qr.property.vue'
export { default as PropertyDialogQrUiProperty } from '../..\\components\\property\\dialog.qr.ui.property.vue'
export { default as PropertyDialogStocksProperty } from '../..\\components\\property\\dialog.stocks.property.vue'
export { default as PropertyDialogTemplateProperty } from '../..\\components\\property\\dialog.template.property.vue'
export { default as Sidebar } from '../..\\components\\sidebar\\index.vue'
export { default as Tab } from '../..\\components\\tab\\index.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
