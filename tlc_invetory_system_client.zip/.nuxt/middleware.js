const middleware = {}

middleware['admin'] = require('..\\middleware\\admin.js')
middleware['admin'] = middleware['admin'].default || middleware['admin']

middleware['pre-load-data'] = require('..\\middleware\\pre-load-data.js')
middleware['pre-load-data'] = middleware['pre-load-data'].default || middleware['pre-load-data']

export default middleware
